module.exports = {
    BookingRepository: require('./booking-repository')
}