module.exports = {
    InfoController: require('./info-controller'),
    BookingController: require('./booking-controller')
}